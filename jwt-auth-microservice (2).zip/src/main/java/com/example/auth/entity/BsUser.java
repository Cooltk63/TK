package com.example.auth.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "bs_user")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BsUser {

    @Id
    @Column(name = "user_id")
    private String userId;

    private String password;

    @Column(name = "user_role")
    private String userRole;
}
