package com.example.auth.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class RedisUtil {

    @Autowired
    private StringRedisTemplate redisTemplate;

    public void storeUserSession(String userId, String token) {
        redisTemplate.opsForValue().set(userId, token, 1, TimeUnit.HOURS);
    }

    public boolean isValidSession(String userId, String token) {
        String stored = redisTemplate.opsForValue().get(userId);
        return token.equals(stored);
    }

    public void removeUserSession(String userId) {
        redisTemplate.delete(userId);
    }
}
