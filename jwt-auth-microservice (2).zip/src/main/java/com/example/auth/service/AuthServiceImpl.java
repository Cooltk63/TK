package com.example.auth.service;

import com.example.auth.dto.AuthRequest;
import com.example.auth.dto.AuthResponse;
import com.example.auth.entity.BsUser;
import com.example.auth.repository.BsUserRepository;
import com.example.auth.util.JwtService;
import com.example.auth.util.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private BsUserRepository userRepo;

    @Autowired
    private RedisUtil redisUtil;

    @Override
    public AuthResponse authenticate(AuthRequest request) {
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUserId(), request.getPassword()));

        BsUser user = userRepo.findByUserId(request.getUserId()).orElseThrow();
        String token = jwtService.generateToken(user);
        redisUtil.storeUserSession(user.getUserId(), token);

        return new AuthResponse(token);
    }

    @Override
    public String logout(String token) {
        String userId = jwtService.extractUsername(token);
        redisUtil.removeUserSession(userId);
        return "Logged out";
    }
}
