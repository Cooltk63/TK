package com.example.auth.service;

import com.example.auth.dto.AuthRequest;
import com.example.auth.dto.AuthResponse;

public interface AuthService {
    AuthResponse authenticate(AuthRequest request);
    String logout(String token);
}
